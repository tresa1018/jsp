console.log('# test.js 파일')
const sample = 10

